<?php
// Display all PHP configuration information
phpinfo();
?>
