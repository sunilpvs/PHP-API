<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/DbController.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/Logger.php';
require $_SERVER['DOCUMENT_ROOT'] . '/classes/utils/GraphAutoMailer.php';

class AccessRequest {
    private $conn;
    private $logger;
    private $mailer;
    

    
    

    public function __construct() {
        $this->mailer = new AutoMail();
        $this->conn = new DBController();
        $config = parse_ini_file($_SERVER['DOCUMENT_ROOT'] . '/app.ini');
        $debugMode = isset($config['DEBUG_MODE']) && in_array(strtolower($config['DEBUG_MODE']), ['1', 'true'], true);
        $logDir = $_SERVER['DOCUMENT_ROOT'] . '/logs';
        $this->logger = new Logger($debugMode, $logDir);
    }



    public function getAllAccessRequests($module, $username) {
        $query = 'SELECT * FROM tbl_access_requests';
        $this->logger->logQuery($query, [], 'classes', $module, $username);
        return $this->conn->runQuery($query);
    }

    public function getAccessRequestById($request_id, $module, $username) {
        $query = "SELECT * FROM tbl_access_requests WHERE id = ?";
        $this->logger->logQuery($query, [$request_id], 'classes', $module, $username);
        return $this->conn->runSingle($query, [$request_id]);
    }

    public function getITAdminEmails($module='Access Request', $username='guest') {
        $emails = "";
        $query = "SELECT email FROM tbl_user_modules WHERE user_role_id = 2"; 
        $this->logger->logQuery($query, [], 'classes', 'Access request', 'guest');
        $results = $this->conn->runQuery($query);
        if (is_array($results) && count($results) > 0) {
            foreach ($results as $row) {
                if (isset($row['email'])) {
                    $emails .= "'".$row['email'] . "',";
                }
            }
        }
        return rtrim($emails, ',');

    }

    public function getAccessRequestsCount($module, $username) {
        $query = 'SELECT COUNT(*) AS total FROM tbl_access_requests';
        $this->logger->logQuery($query, [], 'classes', $module, $username);
        $result = $this->conn->runQuery($query);
        return isset($result[0]['total']) ? (int)$result[0]['total'] : 0;
    }

    // Under Maintenance: get name from the users table
    public function getRequestorNameByEmail($email, $module, $username) {
        $query = "SELECT a.f_name, a.l_name FROM tbl_access_requests b JOIN tbl_contact a ON b.contact_id = a.id
                  WHERE b.email = ?";
        $this->logger->logQuery($query, [$email], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$email]);
        $emp_name = $result ? trim($result['f_name'] . ' ' . $result['l_name']) : null;
        return $emp_name;
    }


    public function getContactIdfromEmail($email, $module, $username) {
        $query = "SELECT id FROM tbl_contact WHERE email = ?";
        $this->logger->logQuery($query, [$email], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$email]);
        return $result ? $result['id'] : null;
    }

    public function insertAccessRequest($requester_email, $contactId, $module, $username) {
        $query = 'INSERT INTO tbl_access_requests (
                    email, contact_id, requested_module, status) 
                    VALUES (?, ?, 4, 8)';

        $params = [$requester_email, $contactId];

        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $logMessage = 'Access request inserted';
        $insertId = $this->conn->insert($query, $params, $logMessage);

        // Send mail to IT Admin
        $ini_file_path = $_SERVER['DOCUMENT_ROOT'] . "/app.ini";
        $config = parse_ini_file($ini_file_path, true)['application'];
        $emp_name = self::getRequestorNameByEmail($requester_email, $module, $username);
        var_dump($emp_name);

        $keyValueData = [
            "Message" => "$emp_name has requested access to the Vendor Management System. 
                            Please review and approve the request. Login to the system to manage the access requests.",
            "Employee Name" => $emp_name,
            "Approval Link" => $config['ADMIN_PORTAL_URL'],
        ];

        $emails = self::getITAdminEmails();
        var_dump($emails);


        $response = $this->mailer->sendEmail(
            to: [$emails],
            subject: 'New Access Request for Vendor Management System',
            keyValueArray: $keyValueData,
            cc: ['bhaskar.teja@pvs-consultancy.com'],
            bcc: ['team.pvs@pvs-consultancy.com'],
            attachments: []
        );

        if($response){
            $updateQuery = 'UPDATE tbl_access_requests SET status = 8 WHERE id = ?';
            $this->logger->logQuery($updateQuery, [$insertId], 'classes', $module, $username);
            $updatedId = $this->conn->update($updateQuery, [$insertId], 'Email sent status updated');
            var_dump($updatedId);
        }
        var_dump($response);
        var_dump($insertId);

        // send a confirmation email to the requester

        if($insertId && $response){
            return $insertId;
        } else {
            return false;
        }
    }

    public function updateAccessRequestStatus($request_id, $status, $module, $username) {

        $query = "SELECT email, requested_module FROM tbl_access_requests WHERE id = ?";
        $this->logger->logQuery($query, [$request_id], 'classes', $module, $username);
        $requestDetails = $this->conn->runSingle($query, [$request_id]);

        if (!$requestDetails) {
            return false;  
        }

        $requestor_email = $requestDetails['email'];
        $requested_module = $requestDetails['requested_module'];

      
        if ($status == 11) {
            $statusMessage = 'approved';
            $statusCode = 11;  
        } elseif ($status == 12) {
            $statusMessage = 'rejected';
            $statusCode = 12;  
        } else {
            return false; 
        }

        $updateQuery = "UPDATE tbl_access_requests SET status = ? WHERE id = ?";
        $this->logger->logQuery($updateQuery, [$statusCode, $request_id], 'classes', $module, $username);
        $this->conn->update($updateQuery, [$statusCode, $request_id], 'Updated access request status');

       
        $ini_file_path = $_SERVER['DOCUMENT_ROOT'] . "/app.ini";
        $config = parse_ini_file($ini_file_path, true)['application'];
        $req_name = self::getRequestorNameByEmail($requestor_email, $module, $username);

        
        
        if($statusMessage == 'approved'){
            $keyValueData = [
                "Message" =>  "Your request for access to the $requested_module - Vendor Management System has been $statusMessage. 
                                Please login to the system to view the status of your requests.",
                "Employee Name" => $req_name,
                
                "VMS Portal Link" => $config['VMS_PORTAL_URL'],
            ];

        } else {
            $keyValueData = [
                "Message" => "Your request for access to the $requested_module - Vendor Management System has been $statusMessage. 
                                For more details, please contact the IT department.",
                "Employee Name" => $req_name,
            ];
        }

        $response = $this->mailer->sendEmail(
            to: [$requestor_email],
            subject: "Your Access Request for $requested_module has been $statusMessage",
            keyValueArray: $keyValueData,
            cc: ['sunil.pvs@pvs-consultancy.com', 'bhaskara.teja@pvs-consultancy.com'],
            bcc: ['team.pvs@pvs-consultancy.com'],
            attachments: []
        );

        if ($response) {
            $this->logger->log('Email sent to requestor: ' . $requestor_email, 'email', $module, $username);
            return true;
        }

        return false; 
    }


    public function checkAccessStatus($email, $module, $username){
        $query = "SELECT status FROM tbl_access_requests WHERE email = ?";
        $this->logger->logQuery($query, [$email], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$email]);
        return $result ? $result['status'] : null;
    }

}


?>