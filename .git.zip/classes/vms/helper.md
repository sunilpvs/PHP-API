CREATE TABLE vms_vendor (
	id INT AUTO_INCREMENT PRIMARY KEY,
    reference_id VARCHAR(20) NOT NULL UNIQUE,  -- link back to RFQ
    vendor_code varchar(50) DEFAULT NULL UNIQUE, -- Created and updated for first time RFQ approval.
    vendor_status int(11), -- Initial, Active, Expired, Suspended, Blocked
    entity_id int(11), 
    
    full_registered_name VARCHAR(255) NOT NULL,
    business_entity_type ENUM('Sole Proprietorship','Partnership','Limited Liability Partnership','Public Limited Companies',
								'Private Limited Companies', 'One-Person Companies', 'Section 8 Company', 'Joint-Venture Company',
								'Non-Government Organization(NGO)')  NOT NULL,
    reg_number VARCHAR(50),
	tan_number VARCHAR(20),
	trading_name VARCHAR(255),
	company_email VARCHAR(255) NOT NULL UNIQUE,
	country_type ENUM('India', 'Others'),
    country_id INT(10),
    state_id INT(10),
    country_text VARCHAR(50),
    state_text VARCHAR(50),
    telephone VARCHAR(50),
    registered_address TEXT NOT NULL,
    business_address TEXT,
    contact_person_name VARCHAR(100),
    contact_person_mobile VARCHAR(15),
    contact_person_email VARCHAR(50),
    accounts_person_name VARCHAR(255),
    accounts_person_contact_no VARCHAR(20),
    accounts_person_email VARCHAR(255),
    
    expiry_date DATETIME DEFAULT NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (reference_id) REFERENCES vms_rfqs(reference_id)
);



full_registered_name,
business_entity_type,
reg_number,
tan_number,
trading_name,
company_email,
country_type,
country_id,
state_id,
country_text,
state_text,
telephone,
registered_address,
business_address,
contact_person_name,
contact_person_email,
contact_person_mobile,
accounts_person_name,
accounts_person_contact_no,
accounts_person_email


$input['full_registered_name'],
$input['business_entity_type'],
$input['reg_number'],
$input['tan_number'],
$input['trading_name'],
$input['company_email'],
$input['country_type'],
$input['country_id'],
$input['state_id'],
$input['country_text'],
$input['state_text'],
$input['telephone'],
$input['registered_address'],
$input['business_address'],
$input['contact_person_name'],
$input['contact_person_email'],
$input['contact_person_mobile'],
$input['accounts_person_name'],
$input['accounts_person_contact_no'],
$input['accounts_person_email']



$full_registered_name,
$business_entity_type,
$reg_number,
$tan_number,
$trading_name,
$company_email,
$country_type,
$country_id,
$state_id,
$country_text,
$state_text,
$telephone,
$registered_address,
$business_address,
$contact_person_name,
$contact_person_email,
$contact_person_mobile,
$accounts_person_name,
$accounts_person_contact_no,
$accounts_person_email





CREATE TABLE vms_bank_accounts (
    bank_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    reference_id VARCHAR(20) NOT NULL,
    account_holder_name VARCHAR(255) NOT NULL,
    bank_name VARCHAR(255) NOT NULL,
    bank_address TEXT,
    transaction_type ENUM('Domestic', 'International', 'Domestic and International'),
    country VARCHAR(100),
    account_number VARCHAR(50) NOT NULL,
    ifsc_code VARCHAR(20),
    swift_code VARCHAR(50),
    beneficiary_name VARCHAR(255),
	FOREIGN KEY(reference_id) REFERENCES vms_rfqs(reference_id)
);


$account_holder_name,
$bank_name,
$bank_address,
$transaction_type,
$country_type,
$country_id,
$country_text,
$account_number,
$ifsc_code,
$swift_code,
$beneficiary_name

account_holder_name,
$bank_name,
$bank_address,
$transaction_type,
$country_type,
$country_id,
$country_text,
$account_number,
$ifsc_code,
$swift_code,
$beneficiary_name

$input['account_holder_name'],
$input['bank_name'],
$input['bank_address'],
$input['transaction_type'],
$input['country_type'],
$input['country_id'],
$input['country_text'],
$input['account_number'],
$input['ifsc_code'],
$input['swift_code'],
$input['beneficiary_name']



