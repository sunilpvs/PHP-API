<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/DbController.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/Logger.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/vms/Rfq.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/utils/GraphAutoMailer.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/vms/CounterPartyInfo.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/vms/Comments.php';

class RfqReview
{
    private $conn;
    private $logger;
    private $rfqData;
    private $counterPartyInfo;
    private $commentOb;
    private $vendorLoginUrl;
    private $vmsPortalUrl;

    public function __construct()
    {
        $this->conn = new DBController();
        $config = parse_ini_file($_SERVER['DOCUMENT_ROOT'] . '/app.ini');
        $debugMode = isset($config['DEBUG_MODE']) && in_array(strtolower($config['DEBUG_MODE']), ['1', 'true'], true);
        $logDir = $_SERVER['DOCUMENT_ROOT'] . '/logs';
        $this->rfqData = new Rfq();
        $this->counterPartyInfo = new CounterPartyInfo();
        $this->commentOb = new Comments();
        $this->logger = new Logger($debugMode, $logDir);
        $this->vendorLoginUrl = $config['vendor_login_url'];
        $this->vmsPortalUrl = $config['vms_portal_url'];
    }

    // send back rfq for corrections with comments
    public function sendBackRfq($reference_id, $module, $username)
    {
        $query = "UPDATE vms_rfqs SET 
                    status = ?
                    WHERE reference_id = ?";

        $params = [
            10,
            $reference_id
        ];

        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $logMessage = 'RFQ sent back for corrections';
        $updatedRfqId =  $this->conn->update($query, $params, $logMessage);

        // update vms_vendor status to sent back for corrections
        $query = "UPDATE vms_vendor SET 
                    vendor_status = ?
                    WHERE reference_id = ?";

        $params = [
            10,
            $reference_id
        ];

        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $logMessage = 'Vendor status updated to sent back for corrections';
        $updatedVendorId =  $this->conn->update($query, $params, $logMessage);

        // get latest comments for the reference id
        $comments = $this->commentOb->getLatestCommentsByReferenceId($reference_id, $module, $username);

        $vendorEmail = $this->rfqData->getEmailByReferenceId($reference_id, $module, $username);

        $commentText = "";

        if (!empty($comments)) {
            foreach ($comments as $comment) {
                $commentText .= $comment['step_name'] . ":\n";
                $lines = preg_split('/\r\n|\r|\n/', trim($comment['comment_text']));
                foreach ($lines as $line) {
                    $commentText .= $line . "\n";
                }
                $commentText .= "\n"; // Add a blank line between steps
            }
        }

        $mailer = new AutoMail();

        // Create the key-value array for the email body
        $keyValueData = [
            "Message" => "Your RFQ with Reference ID: $reference_id has been sent back for corrections. 
                            Please review the comments and make the necessary changes.",
            "Reference ID" => $reference_id,
            "Comments" => $commentText
        ];


        // Prepare email data and send email using the mailer
        $emailSent = $mailer->sendEmail(
            to: [$vendorEmail],
            subject: 'Returned for Revisions - RFQ Reference ID: ' . $reference_id,
            keyValueArray: $keyValueData,
            cc: ['sunil.pvs@pvs-consultancy.com', 'ramalakshmi@pvs-consultancy.com', 'bhaskar.teja@pvs-consultancy.com'],
            bcc: ['team.pvs@pvs-consultancy.com'],
        );


        // Update email_sent status in comments table
        if ($emailSent) {
            $updateEmailSentStatus = $this->commentOb->updateEmailSentStatus($reference_id, 1, $module, $username);
        }

        if ($updatedRfqId && $updatedVendorId && $emailSent && $updateEmailSentStatus) {
            return true;
        } else {
            return false;
        }
    }

    // verify rfq and forward to approval
    public function verifyRfq($reference_id, $expiry_date, $module, $username)
    {

        // Update RFQ status to verified - under review
        $query = "UPDATE vms_rfqs SET 
                    status = ?
                    WHERE reference_id = ?";

        $params = [
            9,
            $reference_id
        ];

        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $logMessage = 'RFQ verified and forwarded for approval';
        $rfqStatusUpdatedId =  $this->conn->update($query, $params, $logMessage);

        // Update vendor status to verified and set expiry date
        $query = "UPDATE vms_vendor SET 
                    expiry_date = ?, vendor_status = ?
                    WHERE reference_id = ?";
        $params = [
            $expiry_date,
            9,
            $reference_id
        ];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $expiryDateUpdatedId = $this->conn->update($query, $params, 'Vendor expiry date set');

        $vendorEmail = $this->rfqData->getEmailByReferenceId($reference_id, $module, $username);

        $mailer = new AutoMail();

        // Create the key-value array for the email body
        $keyValueData = [
            "Message" => "Your RFQ with Reference ID: $reference_id has been verified and forwarded for approval. 
                            You will be notified once the approval process is complete.",
            "Reference ID" => $reference_id,
        ];

        // Prepare email data and send email using the mailer
        $emailSent = $mailer->sendEmail(
            to: [$vendorEmail],
            subject: 'RFQ Verification Completed – Awaiting Approval',
            keyValueArray: $keyValueData,
            cc: ['sunil.pvs@pvs-consultancy.com', 'ramalakshmi@pvs-consultancy.com', 'bhaskar.teja@pvs-consultancy.com'],
            bcc: ['team.pvs@pvs-consultancy.com'],
            attachments: []
        );
        if ($rfqStatusUpdatedId && $expiryDateUpdatedId && $emailSent) {
            return true;
        } else {
            return false;
        }
    }

    // approve rfq and generate vendor id
    public function approveRfq($reference_id, $expiry_date, $module, $username)
    {
        // set expiry date after approval 

        // generate vendor id 
        $vendorCode = $this->counterPartyInfo->generateVendorCode($reference_id, $module, $username);
        if (!$vendorCode) {
            return false; // Vendor ID generation failed
        }

        // update vendor status to approved and set vendor code
        $query = "UPDATE vms_vendor SET 
                    vendor_status = 11,
                    vendor_code = ?
                    WHERE reference_id = ?";
        $params = [
            $vendorCode,
            $reference_id
        ];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $vendorCodeAndStatusUpdatedId = $this->conn->update($query, $params, 'Vendor approved and Vendor ID generated');

        // set vendor code in rfq table
        $query = "UPDATE vms_rfqs SET 
                    vendor_code = ? 
                    WHERE reference_id = ?";
        $params = [
            $vendorCode,
            $reference_id
        ];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $rfqVendorCodeUpdatedId = $this->conn->update($query, $params, 'RFQ vendor code updated');

        // set vendor expiry date
        $query = "UPDATE vms_vendor SET 
                    expiry_date = ? 
                    WHERE reference_id = ?";
        $params = [
            $expiry_date,
            $reference_id
        ];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $expiryDateUpdatedId = $this->conn->update($query, $params, 'Vendor expiry date set');

        // update rfq status to approved
        $query = "UPDATE vms_rfqs SET 
                    status = ?
                    WHERE reference_id = ?";
        $params = [
            11,
            $reference_id
        ];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $rfqUpdatedId = $this->conn->update($query, $params, 'RFQ approved');


        $vendorEmail = $this->rfqData->getEmailByReferenceId($reference_id, $module, $username);

        $mailer = new AutoMail();
        // Create the key-value array for the email body
        $keyValueData = [
            "Message" => "Congratulations! Your RFQ with Reference ID: $reference_id has been approved. 
                            Your Vendor ID is: $vendorCode. You can now proceed with further transactions.",
            "Reference ID" => $reference_id,
            "Vendor ID" => $vendorCode
        ];

        // Prepare email data and send email using the mailer
        $emailSent = $mailer->sendEmail(
            to: [$vendorEmail],
            subject: 'RFQ Approval and Vendor ID Issued',
            keyValueArray: $keyValueData,
            cc: ['sunil.pvs@pvs-consultancy.com', 'ramalakshmi@pvs-consultancy.com', 'bhaskar.teja@pvs-consultancy.com'],
            bcc: ['team.pvs@pvs-consultancy.com'],
            attachments: []
        );


        if (
            $vendorCodeAndStatusUpdatedId && $rfqVendorCodeUpdatedId &&
            $expiryDateUpdatedId && $rfqUpdatedId && $emailSent
        ) {
            return true;
        } else {
            return false;
        }
    }

    // 

    // reject rfq 
    public function rejectRfq($reference_id, $module, $username)
    {
        // update status to rejected in vendor table
        $query = "UPDATE vms_vendor SET 
                    vendor_status = 12 
                    WHERE reference_id = ?";
        $params = [
            $reference_id
        ];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $vendorStatusUpdatedId = $this->conn->update($query, $params, 'Vendor rejected');

        // update status to rejected in rfq table
        $query = "UPDATE vms_rfqs SET 
                    status = 12 
                    WHERE reference_id = ?";

        $params = [
            $reference_id
        ];

        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $logMessage = 'RFQ rejected';
        $rfqStatusUpdatedId =  $this->conn->update($query, $params, $logMessage);

        // get vendor email from reference id
        $vendorEmail = $this->rfqData->getEmailByReferenceId($reference_id, $module, $username);

        $mailer = new AutoMail();

        // Create the key-value array for the email body
        $keyValueData = [
            "Message" => "We regret to inform you that your RFQ with Reference ID: $reference_id has been rejected. 
                            For further details, please contact our support team.",
            "Reference ID" => $reference_id,
        ];

        // Prepare email data and send email using the mailer
        $emailSent = $mailer->sendEmail(
            to: [$vendorEmail],
            subject: "RFQ - $reference_id Rejected",
            keyValueArray: $keyValueData,
            cc: ['sunil.pvs@pvs-consultancy.com', 'ramalakshmi@pvs-consultancy.com', 'bhaskar.teja@pvs-consultancy.com'],
            bcc: ['team.pvs@pvs-consultancy.com'],
            attachments: []
        );

        if ($vendorStatusUpdatedId && $rfqStatusUpdatedId && $emailSent) {
            return true;
        } else {
            return false;
        }
    }

    // submit rfq for review
    public function submitRfqForReview($reference_id, $module, $username)
    {
        // declare emailSent and submissionStatusChanged variables
        $emailSent = false;
        $submissionStatusChanged = false;

        // get vendor email from reference id
        $vendorEmail = $this->rfqData->getEmailByReferenceId($reference_id, $module, $username);

        // check resubmission 
        $isResubmission = $this->rfqData->isFormSubmittedPreviously($reference_id, $module, $username);
        if ($isResubmission) {
            // log resubmission event
            $this->logger->log("Resubmission detected for Reference ID: $reference_id by user: $username", 'classes', $module, $username);

            // update resubmission count
            $this->rfqData->incrementSubmissionCount($reference_id, $module, $username);

            // update rfq and vendor status to 'Submitted' (status id 8)
            $submissionStatusChanged = $this->submitRfqStatusChange($reference_id, $module, $username);

            // send mail notification to vendor
            $mailer = new AutoMail();

            // Create the key-value array for the email body to reviewer
            $keyValueData = [
                "Message" => "Dear VMS Team, The RFQ with Reference ID: $reference_id has been resubmitted by the vendor. 
                                Please review the updated submission at your earliest convenience.",
                "Reference ID" => $reference_id,
                "VMS Portal Link" => $this->vmsPortalUrl,
            ];

            // Prepare email data and send email to reviewer 
            $emailSent = $mailer->sendEmail(
                to: [$vendorEmail],
                subject: "RFQ - $reference_id Resubmitted",
                keyValueArray: $keyValueData,
                cc: ['sunil.pvs@pvs-consultancy.com', 'ramalakshmi@pvs-consultancy.com', 'bhaskar.teja@pvs-consultancy.com'],
                bcc: ['team.pvs@pvs-consultancy.com'],
                attachments: []
            );

            $keyValueData = [
                "Message" => "Dear Vendor, Your data has been successfully resubmitted with Reference ID: $reference_id. 
                            You will be notified once your application is reviewed. You can also check your status by logging
                            into the Vendor Portal with the credentials shared earlier. ",
                "Vendor Portal Link" => $this->vendorLoginUrl,
            ];

            $emailSent = $mailer->sendEmail(
                to: [$vendorEmail],
                subject: 'Vendor Registration Resubmitted - Reference ID: ' . $reference_id,
                keyValueArray: $keyValueData,
                cc: ['sunil.pvs@pvs-consultancy.com', 'ramalakshmi@pvs-consultancy.com', 'bhaskar.teja@pvs-consultancy.com'],
                bcc: ['team.pvs@pvs-consultancy.com'],
                attachments: []
            );

            return $emailSent && $submissionStatusChanged;
        } else {
            // first time submission

            // log first time submission event
            $this->logger->log("First time submission for Reference ID: $reference_id by user: $username", 'classes', $module, $username);
            // update rfq and vendor status to 'Submitted' (status id 8)
            $submissionStatusChanged = $this->submitRfqStatusChange($reference_id, $module, $username);
            // send mail notification to vendor
            $mailer = new AutoMail();
            // Create the key-value array for the email body to reviewer
            $keyValueData = [
                "Message" => "Dear VMS Team, The RFQ with Reference ID: $reference_id has been submitted by the vendor. 
                                Please review the submission at your earliest convenience.",
                "Reference ID" => $reference_id,
                "VMS Portal Link" => $this->vmsPortalUrl,
            ];
            // Prepare email data and send email to reviewer
            $emailSent = $mailer->sendEmail(
                to: [$vendorEmail],
                subject: "RFQ - $reference_id Submitted",
                keyValueArray: $keyValueData,
                cc: ['sunil.pvs@pvs-consultancy.com', 'ramalakshmi@pvs-consultancy.com', 'bhaskar.teja@pvs-consultancy.com'],
                bcc: ['team.pvs@pvs-consultancy.com'],
                attachments: []
            );

            // Send notification email to vendor
            // Create the key-value array for the email body to vendor
            $keyValueData = [
                "Message" => "Dear Vendor, Your data has been successfully submitted with Reference ID: $reference_id. 
                            You will be notified once your application is reviewed. You can also check your status by logging
                            into the Vendor Portal with the credentials shared earlier. ",
                "Vendor Portal Link" => $this->vendorLoginUrl,
            ];

            $emailSent = $mailer->sendEmail(
                to: [$vendorEmail],
                subject: 'Vendor Registration Submitted - Reference ID: ' . $reference_id,
                keyValueArray: $keyValueData,
                cc: ['sunil.pvs@pvs-consultancy.com', 'ramalakshmi@pvs-consultancy.com', 'bhaskar.teja@pvs-consultancy.com'],
                bcc: ['team.pvs@pvs-consultancy.com'],
                attachments: []
            );

            return $emailSent && $submissionStatusChanged;
        }
    }



    // block vendor


    // suspend vendor


    // util methods
    public function checkRfqStatus($reference_id, $module, $username)
    {
        $query = 'SELECT status FROM vms_rfqs WHERE reference_id = ?';
        $this->logger->logQuery($query, [$reference_id], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$reference_id]);
        return $result['status'] ?? null;
    }

    public function submitRfqStatusChange($reference_id, $module, $username)
    {
        // update rfq table status
        $query = 'UPDATE vms_rfqs SET status = ? WHERE reference_id = ?';
        $params = [8, $reference_id];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $updatedRfqTableId = $this->conn->update($query, $params, 'RFQ status updated to Submitted after declaration insertion');

        // update vendor table status to 'Submitted' (status id 8)
        $query = 'UPDATE vms_vendor SET vendor_status = ? WHERE reference_id = ?';
        $params = [8, $reference_id];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $updatedVendorTableId = $this->conn->update($query, $params, 'Vendor status updated to Submitted after declaration insertion');

        if ($updatedRfqTableId && $updatedVendorTableId) {
            return true;
        } else {
            return false;
        }
    }
}
