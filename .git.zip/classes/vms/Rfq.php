<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/DbController.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/Logger.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/utils/GraphAutoMailer.php';

class Rfq
{
    private $conn;
    private $logger;
    private $vendorLoginUrl;
    private $yourEmail;


    public function __construct()
    {
        $this->conn = new DBController();
        $config = parse_ini_file($_SERVER['DOCUMENT_ROOT'] . '/app.ini');
        $debugMode = isset($config['DEBUG_MODE']) && in_array(strtolower($config['DEBUG_MODE']), ['1', 'true'], true);
        $logDir = $_SERVER['DOCUMENT_ROOT'] . '/logs';
        $this->logger = new Logger($debugMode, $logDir);
        $this->vendorLoginUrl = $config['vendor_login_url'];
        $this->yourEmail = $config['app_email'];
    }

    public function getAllRfqs($module, $username)
    {
        $query = 'SELECT * FROM vms_rfqs';
        $this->logger->logQuery($query, [], 'classes', $module, $username);
        return $this->conn->runQuery($query);
    }


    public function getPaginatedRfqs($offset, $limit, $module, $username)
    {
        $limit = max(1, min(100, (int)$limit));
        $offset = max(0, (int)$offset);
        // reference id, entity name, vendor name, contact name, email, mobile, status - display in rfq list interface
        $query = "SELECT 
            r.id,
            r.reference_id,
            r.vendor_name,
            r.contact_name,
            r.email, 
            r.mobile,
            r.entity_id,
            ent.entity_name AS entity,
            r.status,
            stat.status AS status_name,
            r.email_sent,
            r.created_by,
            r.created_datetime,
            r.last_updated,
            r.last_updated_datetime
          FROM vms_rfqs r
          LEFT JOIN tbl_entity ent ON r.entity_id = ent.id
          LEFT JOIN tbl_status stat ON r.status = stat.id
          LIMIT $limit OFFSET $offset";

        $this->logger->logQuery($query, [$limit, $offset], 'classes', $module, $username);
        return $this->conn->runQuery($query);
    }

    public function getRfqsCount($module, $username)
    {
        $query = 'SELECT COUNT(*) AS total FROM vms_rfqs';
        $this->logger->logQuery($query, [], 'classes', $module, $username);
        $result = $this->conn->runQuery($query);
        return isset($result[0]['total']) ? (int)$result[0]['total'] : 0;
    }

    public function getRfqById($id, $module, $username)
    {
        $query = "SELECT 
            r.id,
            r.reference_id,
            r.vendor_name,
            r.contact_name,
            r.email,
            r.mobile,
            r.entity_id,
            ent.entity_name AS entity,
            r.status,
            stat.status AS status_name,
            r.email_sent,
            r.created_by,
            r.created_datetime,
            r.last_updated,
            r.last_updated_datetime
          FROM vms_rfqs r
          LEFT JOIN tbl_entity ent ON r.entity_id = ent.id
          LEFT JOIN tbl_status stat ON r.status = stat.id";

        $this->logger->logQuery($query, [$id], 'classes', $module, $username);
        return $this->conn->runSingle($query, [$id]);
    }

    public function insertRfq($vendor_name, $contact_name, $email, $mobile, $entity_id, $created_by, $module, $username)
    {
        //Generating Reference ID
        $reference_id = $this->generateReferenceId();
        // Inserting RFQ data.
        $query = "INSERT INTO vms_rfqs (reference_id, vendor_name, contact_name, email, mobile, entity_id, status, email_sent, created_by)
                  VALUES (?, ?, ?, ?, ?, ?, 7, false, ?)";
        $params = [$reference_id, $vendor_name, $contact_name, $email, $mobile, $entity_id, $created_by];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $logMessage = 'RFQ Inserted';
        $insertId = $this->conn->insert($query, $params, $logMessage);

        //Create Vendaor Contact using Name, Email and Mobile
        //insert into tbl_contact  contact type = vendor , name = name, email, mobile
        $query = "INSERT INTO tbl_contact (f_name, l_name, email, personal_email, city, state, country, emp_status, department, designation, mobile, contacttype_id, entity_id, createdBy) 
                    VALUES (?, ?, ?, ?, 1, 1, 1, 1, 6, 14, ?, 5, ?, ?)";
        $params = [$contact_name, '', $email, $email, $mobile,  $entity_id, $username];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $vendorContactId = $this->conn->insert($query, $params, 'Vendor contact created');


        //Create user based on Vendor email.
        $randomPassword = bin2hex(random_bytes(4)); // 8 character random password
        $query = 'INSERT INTO tbl_users(user_name, email, password, user_status, contact_id, status, entity_id, createdBy)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
        $hashedPassword = password_hash($randomPassword, PASSWORD_BCRYPT);
        $params = [$email, $email, $hashedPassword, 1, $vendorContactId, 'verified', $entity_id, $created_by];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $userId = $this->conn->insert($query, $params, 'Vendor user created');

        //Insert into tbl_user_modules
        $query = 'INSERT INTO tbl_user_modules (user_id, email, module_id, user_role_id, enabled) 
                    VALUES (?, ?, ?, ?, ?)';
        $params = [$userId, $email, 4, 8, 1]; // Assuming module_id 4 is for VMS and user_role_id 8 is for VMS_VENDOR
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $moduleId = $this->conn->insert($query, $params, 'Vendor user module access created');

        //Sending Email notification to Vendor with login details.

        $mailer = new AutoMail();

        // Create the key-value array for the email body
        $keyValueData = [
            "Message" => "Your company vendor registration process has been initiated. Here are your login details.",
            "Vendor Name" => $vendor_name,
            "Contact Person" => "IT",
            "Your EMail" => $this->yourEmail,
            "Link" => $this->vendorLoginUrl,
            "Login Details" => "
                Username: $email
                Password: $randomPassword"
        ];

        // Prepare email data and send email using the mailer
        $emailSent = $mailer->sendEmail(
            to: [$email],
            subject: 'Vendor Registration Details',
            keyValueArray: $keyValueData,
            cc: ['sunil.pvs@pvs-consultancy.com', 'ramalakshmi@pvs-consultancy.com', 'bhaskar.teja@pvs-consultancy.com'],
            bcc: ['team.pvs@pvs-consultancy.com'],
            attachments: []
        );

        if ($emailSent) {
            // Update email_sent flag in vms_rfqs table
            $updateQuery = 'UPDATE vms_rfqs SET email_sent = true WHERE id = ?';
            $this->logger->logQuery($updateQuery, [$insertId], 'classes', $module, $username);
            $this->conn->update($updateQuery, [$insertId], 'RFQ email_sent updated');
        }

        if ($insertId && $userId && $moduleId && $vendorContactId && $emailSent) {
            return true;
        } else {
            return false;
        }
    }

    // re-initiate RFQ if vendor is expired after initial submission
    public function reinitiateRfq($id, $last_updated, $module, $username)
    {
        // create new RFI with all the existing details except status and email_sent

        // create a new 
    }

    // Not needed as of now 

    public function updateRfq($id, $vendor_name, $contact_name, $email, $mobile, $entity_id, $status, $expiry_date, $last_updated, $module, $username)
    {
        $query = 'UPDATE vms_rfqs SET vendor_name = ?, contact_name = ?, email = ?, mobile = ?, entity_id = ?, status = ?, expiry_date = ?, last_updated = ?, last_updated_datetime = NOW() WHERE id = ?';
        $params = [$vendor_name, $contact_name, $email, $mobile, $entity_id, $status, $expiry_date, $last_updated, $id];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        $logMessage = 'RFQ Updated';
        return $this->conn->update($query, $params, $logMessage);
    }

    // Not needed as of now

    public function deleteRfq($id, $module, $username)
    {
        $query = 'DELETE FROM vms_rfqs WHERE id = ?';
        $this->logger->logQuery($query, [$id], 'classes', $module, $username);
        $logMessage = 'RFQ Deleted';
        return $this->conn->update($query, [$id], $logMessage);
    }


    public function checkDuplicateRfq($vendor_name, $email, $mobile)
    {
        $query = 'SELECT 1 FROM vms_rfqs WHERE lower(trim(vendor_name)) = lower(trim(?)) OR email = ? OR mobile = ?';
        $this->logger->logQuery($query, [$vendor_name, $email, $mobile], 'classes');
        $duplicate = $this->conn->runSingle($query, [$vendor_name, $email, $mobile]);
        return !empty($duplicate);
    }

    public function checkEditDuplicateRfq($vendor_name, $mobile, $id)
    {
        $query = 'SELECT 1 FROM vms_rfqs WHERE lower(trim(vendor_name)) = lower(trim(?)) AND mobile = ? AND id != ?';
        $this->logger->logQuery($query, [$vendor_name, $mobile, $id], 'classes');
        $duplicate = $this->conn->runSingle($query, [$vendor_name, $mobile, $id]);
        return !empty($duplicate);
    }

    // ✅ Vendor Combo
    // public function getVendorCombo($module, $username) {
    //     $fields = ['id', 'reference_id', 'vendor_name', 'email'];
    //     $query = $this->conn->buildSelectQuery('vms_rfqs', $fields, $fields, 'vendor_name ASC');
    //     if (!$query) {
    //         $this->logger->log("Failed to build vendor combo query", 'classes', $module, $username);
    //         return [];
    //     }
    //     $this->logger->logQuery($query, [], 'classes', $module, $username);
    //     return $this->conn->runQuery($query);
    // }


    public function getPendingSubmittedRfqs($module, $username)
    {
        $query = 'SELECT id, reference_id, vendor_name FROM vms_rfqs WHERE status IN (8, 9) ORDER BY vendor_name ASC';
        $this->logger->logQuery($query, [], 'classes', $module, $username);
        return $this->conn->runQuery($query);
    }

    public function getAllSubmittedRfqs($module, $username)
    {
        $query = 'SELECT id, reference_id, vendor_name FROM vms_rfqs WHERE status IN (8,9,10,11,12,13,14) ORDER BY vendor_name ASC';
        $this->logger->logQuery($query, [], 'classes', $module, $username);
        return $this->conn->runQuery($query);
    }

    public function getAllVendors($offset, $limit, $module, $username)
    {
        $query = "SELECT
                    v.id,
                    v.reference_id,
                    v.vendor_code,
                    s.status,
                    e.entity_name,
                    v.business_entity_type,
                    v.reg_number,

                    CASE
                        WHEN v.country_id IS NULL THEN v.country_text
                        ELSE c.country
                    END AS country,

                    CASE
                        WHEN v.state_id IS NULL THEN v.state_text
                        ELSE st.state
                    END AS state,

                    v.telephone,
                    CONCAT(v.contact_person_title, ' ', v.contact_person_name) AS contact_person_name,
                    v.contact_person_mobile,
                    v.contact_person_email,

                    CONCAT(v.accounts_person_title, ' ', v.accounts_person_name) AS accounts_person_name,
                    v.accounts_person_contact_no AS accounts_person_mobile,
                    v.accounts_person_email,

                    v.expiry_date
                FROM vms_vendor v
                LEFT JOIN tbl_country c ON v.country_id = c.id
                LEFT JOIN tbl_state st ON v.state_id = st.id
                JOIN tbl_status s ON v.vendor_status = s.id
                JOIN tbl_entity e ON v.entity_id = e.id
                WHERE v.vendor_code IS NOT NULL AND 
                v.vendor_status IN (11, 13, 14) 
                LIMIT $limit OFFSET $offset";

        $this->logger->logQuery($query, [], 'classes', $module, $username);
        return $this->conn->runQuery($query);
    }

    // ✅ Get Vendor Details by ID
    public function getVendorById($id, $module, $username)
    {
        $query = "SELECT 
            id, reference_id, vendor_name, contact_name, email, mobile, entity_id, status, created_datetime
        FROM vms_rfqs WHERE id = ?";
        $this->logger->logQuery($query, [$id], 'classes', $module, $username);
        return $this->conn->runSingle($query, [$id]);
    }

    public function getEmailByReferenceId($reference_id, $module, $username)
    {
        $query = "SELECT email FROM vms_rfqs WHERE reference_id = ?";
        $this->logger->logQuery($query, [$reference_id], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$reference_id]);
        return $result ? $result['email'] : null;
    }

    // ✅ Review Vendor (Approve / Reject)
    public function reviewVendor($id, $status, $module, $username)
    {
        $query = "UPDATE vms_rfqs 
                SET status = ?, last_updated = ?, last_updated_datetime = NOW() 
                WHERE id = ?";
        $params = [$status, $username, $id];
        $this->logger->logQuery($query, $params, 'classes', $module, $username);

        $result = $this->conn->update($query, $params, "Vendor $status");

        // Get email for notification
        $vendor = $this->getVendorById($id, $module, $username);
        if ($vendor && !empty($vendor['email'])) {
            $this->sendEmail(
                $vendor['email'],
                "Vendor $status Notification",
                "Hello {$vendor['vendor_name']},<br>Your vendor registration has been <b>$status</b>.<br><br>Regards,<br>Admin Team"
            );
        }

        return $result;
    }

    public function getVendorDetailsByRfqId($id, $module, $username)
    {
        $query = "SELECT 
                    r.id,
                    r.reference_id,
                    r.vendor_name,
                    r.contact_name,
                    r.email,
                    r.mobile,
                    r.entity_id,
                    ent.entity_name AS entity,
                    r.status,
                    stat.status AS status_name,
                    r.email_sent,
                    r.created_by,
                    r.created_datetime,
                    r.last_updated,
                    r.last_updated_datetime,

                    -- Vendor Profile Fields from vms_vendor
                    v.full_registered_name,
                    v.business_entity_type,
                    v.trading_name,
                    v.company_email,
                    v.telephone,
                    v.registered_address,
                    v.business_address,
                    v.contact_person_details,
                    v.website,
                    v.country_of_incorporation,
                    v.trade_license_number,
                    v.cin_number,
                    v.pan_number,
                    v.tan_number,
                    v.gst_vat_number,
                    v.accounts_manager_name,
                    v.accounts_manager_contact_no,
                    v.accounts_manager_email,
                    v.msme_registered,
                    v.msme_number,
                    v.msme_category,
                    v.bank_name,
                    v.account_number,
                    v.ifsc_code,
                    v.trade_license_document,
                    v.certificate_document,
                    v.declaration_text
                FROM vms_rfqs r
                LEFT JOIN tbl_entity ent ON r.entity_id = ent.id
                LEFT JOIN tbl_status stat ON r.status = stat.id
                LEFT JOIN vms_vendor v ON r.reference_id = v.reference_id
                WHERE r.id = ?";

        $this->logger->logQuery($query, [$id], 'classes', $module, $username);
        return $this->conn->runSingle($query, [$id]);
    }

    // ✅ Send Email
    private function sendEmail($to, $subject, $message)
    {
        $headers  = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: noreply@yourdomain.com" . "\r\n";
        return mail($to, $subject, $message, $headers);
    }

    private function generateReferenceId()
    {
        $latestId = $this->conn->runSingle("SELECT MAX(id) as max_id FROM vms_rfqs")['max_id'] ?? 0;
        $newId = $latestId + 1;
        return 'RFI-VEN-' . str_pad($newId, 5, '0', STR_PAD_LEFT);
    }

    public function isFormSubmittedPreviously($reference_id, $module, $username)
    {
        $query = "SELECT submission_count FROM vms_rfqs WHERE reference_id = ?";
        $this->logger->logQuery($query, [$reference_id], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$reference_id]);
        if (!empty($result) && isset($result['submission_count']) && $result['submission_count'] > 1) {
            return true; // resubmission
        }

        return false; // first submission
    }

    public function incrementSubmissionCount($reference_id, $module, $username)
    {
        $query = "UPDATE vms_rfqs SET submission_count = submission_count + 1 WHERE reference_id = ?";
        $this->logger->logQuery($query, [$reference_id], 'classes', $module, $username);
        return $this->conn->update($query, [$reference_id], 'Incremented submission count');
    }
}
