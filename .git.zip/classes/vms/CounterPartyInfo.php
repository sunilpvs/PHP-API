<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/DbController.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/Logger.php';

class CounterPartyInfo
{
    private $conn;
    private $logger;

    public function __construct()
    {
        $this->conn = new DBController();
        $config = parse_ini_file($_SERVER['DOCUMENT_ROOT'] . '/app.ini');
        $debugMode = isset($config['DEBUG_MODE']) && in_array(strtolower($config['DEBUG_MODE']), ['1', 'true'], true);
        $logDir = $_SERVER['DOCUMENT_ROOT'] . '/logs';
        $this->logger = new Logger($debugMode, $logDir);
    }

    public function getAllVendors($module, $username)
    {
        $query = "SELECT 
                    v.id,
                    v.reference_id,
                    v.vendor_code,
                    v.vendor_status AS status_id,
                    st.status AS status,
                    e.entity_name,
                    v.full_registered_name,
                    v.business_entity_type,
                    v.reg_number,
                    v.tan_number,
                    v.trading_name,
                    v.country_type,
                    v.country_id AS country_id,
                    v.state_id AS state_id,
                    c.country AS country_name,
                    s.state AS state_name,
                    v.country_text AS country_text,
                    v.state_text AS state_text,
                    v.telephone,
                    v.registered_address,
                    v.business_address,
                    v.contact_person_title,
                    v.contact_person_name,
                    v.contact_person_email,
                    v.contact_person_mobile,
                    v.accounts_person_title,
                    v.accounts_person_name,
                    v.accounts_person_contact_no,
                    v.accounts_person_email
                FROM vms_vendor v
                LEFT JOIN tbl_country c ON v.country_id = c.id
                LEFT JOIN tbl_state s ON v.state_id = s.id
                LEFT JOIN tbl_entity e ON v.entity_id = e.id
                LEFT JOIN tbl_status st ON v.vendor_status = st.id";
        $this->logger->logQuery($query, [], 'classes', $module, $username);
        return $this->conn->runQuery($query);
    }

    public function getEntityIdByReference($referenceId, $module, $username)
    {
        $query = "SELECT entity_id FROM vms_rfqs WHERE reference_id = ?";
        $this->logger->logQuery($query, [$referenceId], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$referenceId]);
        return $result['entity_id'] ?? null;
    }

    public function getVendorByReferenceId($reference_id, $module, $username)
    {
        $query = "SELECT 
                    v.id,
                    v.reference_id,
                    v.vendor_code,
                    v.vendor_status AS status_id,
                    st.status AS status,
                    e.entity_name,
                    v.full_registered_name,
                    v.business_entity_type,
                    v.reg_number,
                    v.tan_number,
                    v.trading_name,
                    v.country_type,
                    v.country_id AS country_id,
                    v.state_id AS state_id,
                    c.country AS country_name,
                    s.state AS state_name,
                    v.country_text AS country_text,
                    v.state_text AS state_text,
                    v.telephone,
                    v.registered_address,
                    v.business_address,
                    v.contact_person_title,
                    v.contact_person_name,
                    v.contact_person_email,
                    v.contact_person_mobile,
                    v.accounts_person_title,
                    v.accounts_person_name,
                    v.accounts_person_contact_no,
                    v.accounts_person_email
                /**
                 * SQL query fragment to select data from the vms_vendor table.
                 * This FROM clause specifies the vms_vendor table as the data source
                 * with alias 'v' for use in JOIN operations or column references.
                 */
                FROM vms_vendor v
                LEFT JOIN tbl_country c ON v.country_id = c.id
                LEFT JOIN tbl_state s ON v.state_id = s.id
                LEFT JOIN tbl_entity e ON v.entity_id = e.id
                LEFT JOIN tbl_status st ON v.vendor_status = st.id 
                WHERE v.reference_id = ?";
        $this->logger->logQuery($query, [$reference_id], 'classes', $module, $username);
        return $this->conn->runSingle($query, [$reference_id]);
    }

    // public function getReferenceIdf

    public function getPaginatedVendors($offset, $limit, $module, $username)
    {
        $limit = max(1, min(100, (int)$limit));
        $offset = max(0, (int)$offset);
        $query = "SELECT 
                    v.id,
                    v.reference_id,
                    v.vendor_code,
                    v.vendor_status AS status_id,
                    st.status AS status,
                    e.entity_name,
                    v.full_registered_name,
                    v.business_entity_type,
                    v.reg_number,
                    v.tan_number,
                    v.trading_name,
                    v.country_type,
                    v.country_id AS country_id,
                    v.state_id AS state_id,
                    c.country AS country_name,
                    s.state AS state_name,
                    v.country_text AS country_text,
                    v.state_text AS state_text,
                    v.telephone,
                    v.registered_address,
                    v.business_address,
                    v.contact_person_title,
                    v.contact_person_name,
                    v.contact_person_email,
                    v.contact_person_mobile,
                    v.accounts_person_title,
                    v.accounts_person_name,
                    v.accounts_person_contact_no,
                    v.accounts_person_email
                FROM vms_vendor v
                LEFT JOIN tbl_country c ON v.country_id = c.id
                LEFT JOIN tbl_state s ON v.state_id = s.id
                LEFT JOIN tbl_entity e ON v.entity_id = e.id
                LEFT JOIN tbl_status st ON v.vendor_status = st.id LIMIT $limit OFFSET $offset";
        $this->logger->logQuery($query, [$limit, $offset], 'classes', $module, $username);
        return $this->conn->runQuery($query);
    }

    public function getVendorsCount($module, $username)
    {
        $query = 'SELECT COUNT(*) AS total FROM vms_vendor';
        $this->logger->logQuery($query, [], 'classes', $module, $username);
        $result = $this->conn->runQuery($query);
        return isset($result[0]['total']) ? (int)$result[0]['total'] : 0;
    }

    public function insertVendor(
        $reference_id,
        $full_registered_name,
        $business_entity_type,
        $reg_number,
        $tan_number,
        $trading_name,
        $country_type,
        $country_id,
        $state_id,
        $country_text,
        $state_text,
        $telephone,
        $registered_address,
        $business_address,
        $contact_person_title,
        $contact_person_name,
        $contact_person_email,
        $contact_person_mobile,
        $accounts_person_title,
        $accounts_person_name,
        $accounts_person_contact_no,
        $accounts_person_email,
        $module,
        $username
    ) {

        // Check if reference exists in RFQs
        $entity_id = $this->getEntityIdByReference($reference_id, $module, $username);

        if (!$entity_id) {
            throw new Exception("Entity not found for reference ID: " . $reference_id);
        }

        // SQL query for inserting vendor
        $query = "INSERT INTO vms_vendor (
            reference_id, vendor_status, entity_id, 
            full_registered_name,
            business_entity_type,
            reg_number,
            tan_number,
            trading_name,
            country_type,
            country_id,
            state_id,
            country_text,
            state_text,
            telephone,
            registered_address,
            business_address,
            contact_person_title,
            contact_person_name,
            contact_person_email,
            contact_person_mobile,
            accounts_person_title,
            accounts_person_name,
            accounts_person_contact_no,
            accounts_person_email
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // Params array without the fixed value `7` for `vendor_status`
        $params = [
            $reference_id,
            7,                      // Assuming status 7 means 'Initial'
            $entity_id,
            $full_registered_name,
            $business_entity_type,
            $reg_number,
            $tan_number,
            $trading_name,
            $country_type,
            $country_id,
            $state_id,
            $country_text,
            $state_text,
            $telephone,
            $registered_address,
            $business_address,
            $contact_person_title,
            $contact_person_name,
            $contact_person_email,
            $contact_person_mobile,
            $accounts_person_title,
            $accounts_person_name,
            $accounts_person_contact_no,
            $accounts_person_email
        ];

        // Log query for debugging
        $this->logger->logQuery($query, $params, 'classes', $module, $username);

        // Execute the insert operation
        return $this->conn->insert($query, $params, 'Vendor Inserted');
    }


    public function updateVendor(
        $reference_id,
        $full_registered_name,
        $business_entity_type,
        $reg_number,
        $tan_number,
        $trading_name,
        $country_type,
        $country_id,
        $state_id,
        $country_text,
        $state_text,
        $telephone,
        $registered_address,
        $business_address,
        $contact_person_title,
        $contact_person_name,
        $contact_person_email,
        $contact_person_mobile,
        $accounts_person_title,
        $accounts_person_name,
        $accounts_person_contact_no,
        $accounts_person_email,
        $module,
        $username,

    ) {

        $entity_id = $this->getEntityIdByReference($reference_id, $module, $username);

        $query = "UPDATE vms_vendor SET
                    vendor_status = ?, entity_id = ?, 
                    full_registered_name = ?,
                    business_entity_type = ?,
                    reg_number = ?,
                    tan_number = ?,
                    trading_name = ?,
                    country_type = ?,
                    country_id = ?,
                    state_id = ?,
                    country_text = ?,
                    state_text = ?,
                    telephone = ?,
                    registered_address = ?,
                    business_address = ?,
                    contact_person_title = ?,
                    contact_person_name = ?,
                    contact_person_email = ?,
                    contact_person_mobile = ?,
                    accounts_person_title = ?,
                    accounts_person_name = ?,
                    accounts_person_contact_no = ?,
                    accounts_person_email = ?
                    WHERE reference_id = ?";

        $params = [
            8,                      // Assuming status 8 means 'Submitted'
            $entity_id,
            $full_registered_name,
            $business_entity_type,
            $reg_number,
            $tan_number,
            $trading_name,
            $country_type,
            $country_id,
            $state_id,
            $country_text,
            $state_text,
            $telephone,
            $registered_address,
            $business_address,
            $contact_person_title,
            $contact_person_name,
            $contact_person_email,
            $contact_person_mobile,
            $accounts_person_title,
            $accounts_person_name,
            $accounts_person_contact_no,
            $accounts_person_email,
            $reference_id
        ];

        // Log query
        $this->logger->logQuery($query, $params, 'classes', $module, $username);
        // Execute the update operation
        return $this->conn->update($query, $params, 'Vendor Updated');
    }


    public function deleteVendor($vendor_id, $module, $username)
    {
        $query = 'DELETE FROM vms_vendor WHERE id = ?';
        $this->logger->logQuery($query, [$vendor_id], 'classes', $module, $username);
        return $this->conn->update($query, [$vendor_id], 'Vendor Deleted');
    }


    public function checkDuplicateByPAN($pan)
    {
        $query = 'SELECT 1 FROM vms_vendor WHERE lower(trim(pan_number)) = lower(trim(?))';
        $this->logger->logQuery($query, [$pan], 'classes');
        return !empty($this->conn->runSingle($query, [$pan]));
    }


    public function checkEditDuplicateByPAN($pan, $vendor_id)
    {
        $query = 'SELECT 1 FROM vms_vendor WHERE lower(trim(pan_number)) = lower(trim(?)) AND id != ?';
        $this->logger->logQuery($query, [$pan, $vendor_id], 'classes');
        return !empty($this->conn->runSingle($query, [$pan, $vendor_id]));
    }

    public function getReferenceIdByEmail($email, $module, $username)
    {
        try {
            $query = "SELECT v.reference_id
                FROM tbl_users u
                JOIN tbl_contact c ON u.contact_id = c.id
                JOIN vms_rfqs v ON c.email = v.email
                WHERE u.email = ?
                LIMIT 1";

            $this->logger->logQuery($query, [$email], 'classes', $module, $username);
            $result = $this->conn->runSingle($query, [$email]);
            return $result['reference_id'] ?? null;
        } catch (Exception $e) {
            $this->logger->log("Error fetching reference_id for email $email: " . $e->getMessage());
            return null;
        }
    }

    public function getVendorIdByReference($referenceId)
    {
        try {
            $query = "SELECT v.id AS vendor_id 
                      FROM vms_vendor v 
                      JOIN vms_rfqs r ON v.reference_id = r.reference_id
                      WHERE r.reference_id = ?";

            $this->logger->logQuery($query, [$referenceId], 'classes');
            $result = $this->conn->runSingle($query, [$referenceId]);
            return $result['vendor_id'] ?? null;
        } catch (Exception $e) {
            $this->logger->log("Error fetching vendor_id for Reference ID $referenceId: " . $e->getMessage());
            return null;
        }
    }

    // Financial Year in format YY-YY
    public function getCurrentFinancialYear()
    {
        $currentYear = (int)date('Y');
        $currentMonth = (int)date('m');

        if ($currentMonth >= 4) {
            $startYear = $currentYear;
            $endYear = $currentYear + 1;
        } else {
            $startYear = $currentYear - 1;
            $endYear = $currentYear;
        }

        return substr($startYear, -2) . '-' . substr($endYear, -2);
    }

    public function getStateCodeByStateId($stateId, $module, $username)
    {
        $query = 'SELECT code FROM tbl_state WHERE id = ?';
        $this->logger->logQuery($query, [$stateId], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$stateId]);
        return $result['code'] ?? null;
    }

    public function getStateByReferenceId($referenceId, $module, $username)
    {
        // get state (tbl_state linked via state_id) from vms_vendor if its india else get state_text
        $query = 'SELECT st.code FROM vms_vendor v JOIN tbl_state st ON v.state_id = st.id WHERE v.reference_id = ?';
        $this->logger->logQuery($query, [$referenceId], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$referenceId]);
        $stateId = $result['code'] ?? null;    
        if ($stateId !== null) {
            return $stateId;
        } else {
            $query = 'SELECT state_text FROM vms_vendor WHERE reference_id = ?';
            $this->logger->logQuery($query, [$referenceId], 'classes', $module, $username);
            $result = $this->conn->runSingle($query, [$referenceId]);
            return $result['state_text'] ?? null;
        }
    }

    public function getEntityCodeByEntityId($entityId, $module, $username)
    {
        $query = 'SELECT cc_code FROM tbl_costcenter WHERE entity_id = ?';
        $this->logger->logQuery($query, [$entityId], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$entityId]);
        return $result['cc_code'] ?? null;
    }

    public function getEntityByReferenceId($referenceId, $module, $username)
    {
        $query = 'SELECT entity_id FROM vms_rfqs WHERE reference_id = ?';
        $this->logger->logQuery($query, [$referenceId], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$referenceId]);
        $entityId = $result['entity_id'] ?? null;
        if ($entityId !== null) {
            return $this->getEntityCodeByEntityId($entityId, $module, $username);
        } else {
            return null;
        }
    }

    // Vendor Code Format : <EntityCode>-<StateCode>-<FinancialYear>-<4DigitSerialNo>
    public function generateVendorCode($referenceId, $module, $username)
    {
        // $entityCode = $this->getEntityByReferenceId($referenceId, $module, $username);
        $vendorCodePrefix = "VNDR";
        $stateCode = $this->getStateByReferenceId($referenceId, $module, $username);
        $financialYear = $this->getCurrentFinancialYear();

        if (!$vendorCodePrefix || !$stateCode) {
            $this->logger->log("Cannot generate Vendor Code: Missing Entity Code or State Code for Reference ID $referenceId");
            return null;
        }

        $prefix = "{$vendorCodePrefix}/{$stateCode}/{$financialYear}/";

        $query = "SELECT COUNT(*) AS count FROM vms_vendor WHERE vendor_code LIKE ?";
        $likePattern = $prefix . '%';
        $this->logger->logQuery($query, [$likePattern], 'classes', $module, $username);
        $result = $this->conn->runSingle($query, [$likePattern]);
        $count = isset($result['count']) ? (int)$result['count'] : 0;

        $serialNumber = str_pad($count + 1, 4, '0', STR_PAD_LEFT);
        return $prefix . $serialNumber;
    }
}
