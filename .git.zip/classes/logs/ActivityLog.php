<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/classes/DbController.php';

class ActivityLog {
    private $conn;

    public function __construct() {
        $this->conn = new DBController();
    }

    public function getLogs($limit = 10, $offset = 0, $module = null, $username = null, $fromDate = null, $toDate = null) {
        $query = "SELECT datetime, activity, log, user_id FROM vw_activitylog WHERE 1=1";
        $params = [];

        if ($module) {
            $query .= " AND module = ?";
            $params[] = $module;
        }


        if ($username) {
            $query .= " AND username = ?";
            $params[] = $username;
        }
        

        if ($fromDate) {
            $query .= " AND datetime >= ?";
            $params[] = $fromDate . " 00:00:00";
        }

        if ($toDate) {
            $query .= " AND datetime <= ?";
            $params[] = $toDate . " 23:59:59";
        }

        $query .= " ORDER BY datetime DESC LIMIT $limit OFFSET $offset";

        return $this->conn->runQuery($query, $params);
    }

    public function getTotalCount($module = null, $username = null, $fromDate = null, $toDate = null) {
        $query = "SELECT COUNT(*) AS total FROM vw_activitylog WHERE 1=1";
        $params = [];

        if ($module) {
            $query .= " AND module = ?";
            $params[] = $module;
        }

        if ($username) {
            $query .= " AND username = ?";
            $params[] = $username;
        }

        if ($fromDate) {
            $query .= " AND datetime >= ?";
            $params[] = $fromDate . " 00:00:00";
        }

        if ($toDate) {
            $query .= " AND datetime <= ?";
            $params[] = $toDate . " 23:59:59";
        }

        $result = $this->conn->runQuery($query, $params);
        return $result[0]['total'] ?? 0;
    }
}
