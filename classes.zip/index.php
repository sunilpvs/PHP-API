<?php
// Display all PHP configuration information

echo date_default_timezone_get();

?>
